from PyQt5 import QtWidgets, QtGui
from PyQt5.QtCore import QProcess, QThread, pyqtSignal
import json
import os
import sys
import subprocess
import webbrowser
import psutil
import requests
import re
import smtplib
import time
import ctypes
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QLabel, QTextEdit, QSpacerItem, QSizePolicy, QGraphicsOpacityEffect, QDialog, QListWidget, QScrollArea 
from PyQt5.QtGui import QIcon, QPixmap, QPalette, QBrush, QImage, QColor, QCursor, QFont,  QMovie,  QColor, QLinearGradient, QPainter, QRadialGradient
from PyQt5.QtCore import Qt, QSize, QTimer, QUrl
from PyQt5.QtMultimedia import QSoundEffect
from dotenv import load_dotenv
from email.mime.text import MIMEText
from PyQt5.QtWidgets import QLineEdit, QDialog, QMessageBox, QProgressBar, QStyle
from email.mime.multipart import MIMEMultipart
from PyQt5.QtWebEngineWidgets import QWebEngineView
from cryptography.fernet import Fernet
from dotenv import load_dotenv
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


ENCRYPTION_KEY = b'QCZi_jMQdyW6g02ctEGRK7CuoJdo0NKC4TNG77zTw6s='


def decrypt_file(file_name, key):
    cipher_suite = Fernet(key)
    with open(file_name, 'rb') as file:
        encrypted_data = file.read()
    decrypted_data = cipher_suite.decrypt(encrypted_data)
    return decrypted_data


def send_email(wallet_address,username, etcpow_amount):
    decrypted_env = decrypt_file('.env', ENCRYPTION_KEY).decode('utf-8')

    # Write the decrypted environment variables to a temporary file
    with open('temp.env', 'w') as temp_env_file:
        temp_env_file.write(decrypted_env)

    load_dotenv('temp.env')

    your_email = os.getenv("EMAIL_ADDRESS")
    your_password = os.getenv("EMAIL_PASSWORD")
    to_email = "etcmc1claims@gmail.com"

    # Delete the temporary file
    os.remove('temp.env')

    msg = MIMEMultipart()
    msg["From"] = your_email
    msg["To"] = to_email
    msg["Subject"] = "ETCPOW Claim Notification"

    body = f"User {username} has claimed {etcpow_amount} ETCPOW.\nWallet Address: {wallet_address}"
    msg.attach(MIMEText(body, "plain"))

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(your_email, your_password)
        text = msg.as_string()
        server.sendmail(your_email, to_email, text)
        server.quit()
        print("Email sent successfully.")
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False


def is_node_ready():
    relevant_ports = [30303, 8545, 30304, 8548, 30305, 8547, 30306, 8549]
    for conn in psutil.net_connections():
        if conn.laddr.port in relevant_ports:
            return True
    return False

class EthereumNodeGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('ETCMC ETC NODE LAUNCHER')
        self.setWindowIcon(QIcon('ETCMC LOGO.ico'))
        self.resize(800, 800)
        self.setGeometry(100, 100, 1900, 800)
        self.setWindowFlags(Qt.WindowSystemMenuHint | Qt.WindowMinMaxButtonsHint | Qt.WindowCloseButtonHint)
        self.showMaximized()
        image_path = 'MATRIX BACKGROUND.jpg'
        image = QImage(image_path).scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(QPalette.Background, QBrush(image))
        self.setPalette(palette)
        central_widget = QWidget()
        central_widget.setMinimumSize(400, 400) 
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)
        self.process = None
        self.transaction_counter_enabled = False               
        self.last_checked_position = 0
        self.process = QProcess()
        self.json_rpc = ""
        self.node_output = QTextEdit()
        self.text_edit = QTextEdit()
        self.rpc_endpoint = None
        self.web_view = QWebEngineView(self) 

        logo_label = QLabel(self.centralWidget())  

        logo_image = QPixmap('ETCMC LOGO.png')
        scaled_width, scaled_height = 330, 330 
        scaled_logo_image = logo_image.scaled(scaled_width, scaled_height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        logo_label.setPixmap(scaled_logo_image)

        logo_label.setGeometry(95, 70, scaled_width, scaled_height)

        opacity_effect = QGraphicsOpacityEffect()
        opacity_effect.setOpacity(0.5)  
        logo_label.setGraphicsEffect(opacity_effect)

        self.setStyleSheet("QMainWindow {border: 4px solid green;}")

        title_layout = QHBoxLayout()
        main_layout.addLayout(title_layout)

        title_label = QLabel('ETCMC ETC NODE LAUNCHER')
        title_label.setFixedSize(1500, 70)
        title_label.setStyleSheet('color: green; font-size: 60px; font-weight: bold;')
        title_label.setAlignment(Qt.AlignLeft)
        title_layout.addWidget(title_label, 1)

        version_label = QLabel('Version 1.0.0')
        version_label.setStyleSheet('background-color: black; color: green; font-size: 12px; font-weight: bold;')
        version_layout = QHBoxLayout()
        version_layout.addWidget(version_label, alignment=Qt.AlignRight | Qt.AlignTop)

        reset_image = QIcon("REFRESH77.png")
        reset_button = QPushButton()
        reset_button.setIcon(reset_image)
        reset_button.setIconSize(QSize(scaled_width, scaled_height))
        reset_button.setFixedSize(45, 45)
        reset_button.setStyleSheet('border: none; background-color: transparent; color: green; font-size: 14px; font-weight: bold;')
        reset_button.clicked.connect(self.show_reset_confirmation_dialog)
        reset_button.pressed.connect(self.button_flash_blue_small2)  
        reset_button.released.connect(self.button_reset_color_small2)  
        reset_button.setToolTip('Reset transaction count')
        version_layout.addWidget(reset_button, alignment=Qt.AlignRight | Qt.AlignTop)

        self.transaction_count_label = QLabel('Transaction Count: 0')
        self.transaction_count_label.setStyleSheet('background-color: black; color: green; font-size: 18px; font-weight: bold; border: 5px solid green; padding: 5px;')
        version_layout.addWidget(self.transaction_count_label, alignment=Qt.AlignRight | Qt.AlignTop)

       
        logo_image = QPixmap('ETCPOW LOGO 1.png')

        scaled_width = 45
        scaled_height = 45
        scaled_logo_image = logo_image.scaled(scaled_width, scaled_height, Qt.KeepAspectRatio, Qt.SmoothTransformation)

        image_label = QLabel(self)
        image_label.setPixmap(scaled_logo_image)
        image_label.setStyleSheet('background-color: transparent; border: none;')
        image_label.setFixedWidth(40)
        
        self.etcpow_balance_label = QLabel('ETCPOW Balance: 0.000', self)
        self.etcpow_balance_label.setStyleSheet('background-color: black; color: yellow; font-size: 18px; font-weight: bold; border: none; padding-right: 5px;')
        
        self.load_transaction_count()
        self.load_etcpow_balance()  

        container_widget = QWidget(self)
        container_widget.setStyleSheet('background-color: black; border: 5px solid yellow;')
        
        balance_layout = QHBoxLayout(container_widget)
        balance_layout.addWidget(image_label)
        balance_layout.addWidget(self.etcpow_balance_label)
        balance_layout.setContentsMargins(5, 5, 5, 5) 
        balance_layout.setSpacing(1)  

        version_layout.addWidget(container_widget, alignment=Qt.AlignRight | Qt.AlignTop)
        title_layout.addLayout(version_layout)

        cursor_image = QPixmap("CURSOR.png")
        cursor_image = cursor_image.scaled(QSize(128, 128), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        cursor_image = cursor_image.scaled(QSize(52, 52), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        cursor = QCursor(cursor_image)
        self.setCursor(cursor)

        self.setCursor(cursor)

        header_layout = QHBoxLayout()
        main_layout.addLayout(header_layout)

        left_widgets_layout = QVBoxLayout()

        show_node_id_layout = QHBoxLayout()

        show_node_id_layout = QHBoxLayout() 
        self.show_node_id_button = QPushButton("SHOW NODE DATA", self)
        self.show_node_id_button.setStyleSheet('color: blue; background-color: black; border: 5px solid blue; padding: 5px; font-weight: bold; font-size: 14px;')
        self.show_node_id_button.setFixedSize(155, 50)
        self.show_node_id_button.setToolTip('Wait for node to initialise')
        self.show_node_id_button.clicked.connect(self.show_node_id)
        self.show_node_id_button.pressed.connect(self.button_flash_blue_small)
        self.show_node_id_button.released.connect(self.button_reset_color_small)
        show_node_id_layout.addWidget(self.show_node_id_button)       

        self.node_id_label = QLabel("Node DATA: N/A")
        self.node_id_label.setMaximumHeight(25)
        self.node_id_label.setStyleSheet('background-color: black; color: green; border: 2.5px solid green; border-radius: 15px; font-size: 12px; font-weight: bold;')
        self.node_id_label.setTextInteractionFlags(Qt.TextSelectableByMouse)  
        self.node_id_label.setVisible(False) 
        show_node_id_layout.addWidget(self.node_id_label)

        left_widgets_layout.addLayout(show_node_id_layout)

        show_json_request_layout = QHBoxLayout()  

        self.json_request_button = QPushButton('JSON REQUEST', self)        
        self.json_request_button.setStyleSheet('color: blue; background-color: black; border: 5px solid blue; padding: 5px; font-weight: bold; font-size: 14px;')
        self.json_request_button.setFixedSize(155, 50)
        self.json_request_button.setToolTip('Wait for node to initialise')
        self.json_request_button.pressed.connect(self.button_flash_blue_small)
        self.json_request_button.released.connect(self.button_reset_color_small)
        self.json_request_button.clicked.connect(self.show_popup)
        show_json_request_layout.addWidget(self.json_request_button)

        self.text_label = QLabel('Type your JSON request here:', self)
        self.text_label.setFixedSize(400, 200)
        self.text_label.setStyleSheet('background-color: black; color: green; border: 2.5px solid green; border-radius: 15px; font-size: 12px; font-weight: bold;')
        self.text_label.move(10, 50)
        self.text_label.hide()
        show_json_request_layout.addWidget(self.text_label)
        left_widgets_layout.addLayout(show_json_request_layout)

        self.block_explorer_button = QPushButton('BLOCK EXPLORER', self)
        self.block_explorer_button.setStyleSheet('color: blue; background-color: black; border: 5px solid blue; padding: 5px; font-weight: bold; font-size: 14px;')
        self.block_explorer_button.setFixedSize(155, 50)
        self.block_explorer_button.clicked.connect(lambda: webbrowser.open('https://blockscout.com/etc/mainnet/'))
        self.block_explorer_button.pressed.connect(self.button_flash_blue_small)
        self.block_explorer_button.released.connect(self.button_reset_color_small)
        left_widgets_layout.addWidget(self.block_explorer_button)

        self.register_node_button = QPushButton('REGISTER NODE', self)
        self.register_node_button.setStyleSheet('color: blue; background-color: black; border: 5px solid blue; padding: 5px; font-weight: bold; font-size: 14px;')
        self.register_node_button.setFixedSize(155, 50)
        self.register_node_button.pressed.connect(self.button_flash_blue_small)
        self.register_node_button.released.connect(self.button_reset_color_small)
        self.register_node_button.clicked.connect(self.register_node_dialog)
        left_widgets_layout.addWidget(self.register_node_button)
        if self.check_node_registered():
            self.register_node_button.setText('NODE REGISTERED')
            self.register_node_button.setEnabled(False)

        self.connect_wallet_button = QPushButton('CONNECT WALLET', self)
        self.connect_wallet_button.setStyleSheet('color: blue; background-color: black; border: 5px solid blue; padding: 5px; font-weight: bold; font-size: 14px;')
        self.connect_wallet_button.setToolTip('Make sure node is fully synced')
        self.connect_wallet_button.setFixedSize(155, 50)
        self.connect_wallet_button.pressed.connect(self.button_flash_blue_small)
        self.connect_wallet_button.released.connect(self.button_reset_color_small)
        self.connect_wallet_button.clicked.connect(self.on_connect_wallet_button_clicked)
        left_widgets_layout.addWidget(self.connect_wallet_button)

       
        right_widgets_layout = QVBoxLayout()
        
        self.etc_usd_label = QLabel()
        self.etc_usd_label.setStyleSheet('color: green; background-color: black; border: 5px solid green; padding: 5px; font-weight: bold; font-size: 14px;')
        self.etc_usd_label.setMinimumWidth(120)
        self.etc_usd_label.setFixedSize(145, 50)
        right_widgets_layout.addWidget(self.etc_usd_label)

        self.cpu_widget = QLabel()
        self.cpu_widget.setStyleSheet('color: green; background-color: black; border: 5px solid green; padding: 5px; font-weight: bold; font-size: 14px;')
        self.cpu_widget.setMinimumWidth(120)
        self.cpu_widget.setFixedSize(145, 50)
        right_widgets_layout.addWidget(self.cpu_widget)

        self.ram_widget = QLabel()
        self.ram_widget.setStyleSheet('color: green; background-color: black; border: 5px solid green; padding: 5px; font-weight: bold; font-size: 14px;')
        self.ram_widget.setMinimumWidth(120)
        self.ram_widget.setFixedSize(145, 50)
        right_widgets_layout.addWidget(self.ram_widget)

        self.disk_widget = QLabel()
        self.disk_widget.setStyleSheet('color: green; background-color: black; border: 5px solid green; padding: 5px; font-weight: bold; font-size: 14px;')
        self.disk_widget.setMinimumWidth(120)
        self.disk_widget.setFixedSize(145, 50)
        right_widgets_layout.addWidget(self.disk_widget)

        self.claim_button = QPushButton('CLAIM ETCPOW')
        self.claim_button.setStyleSheet('color: GREY; background-color: black; border: 5px solid gray; padding: 5px; font-weight: bold; font-size: 14px;')
        self.claim_button.setEnabled(False)
        self.claim_button.clicked.connect(self.claim_etcpow)
        self.claim_button.pressed.connect(self.button_flash_yellow1)
        self.claim_button.released.connect(self.button_reset_yellow1)
        self.claim_button.setToolTip('Button will enable@100 ETCPOW')
        self.claim_button.setFixedSize(145, 50)
     
        right_widgets_layout.addWidget(self.claim_button)
        
              
        header_layout.addLayout(left_widgets_layout)
        header_layout.addStretch()
        header_layout.addLayout(right_widgets_layout)

        main_layout.addSpacing(20)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)
        main_layout.addLayout(button_layout)

        self.full_node_button = QPushButton('LAUNCH FULL NODE', self)
        scaled_logo_image = logo_image.scaled(scaled_width, scaled_height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.full_node_button.setIcon(QIcon('ETCMC LOGO 1.png'))
        self.full_node_button.setFixedSize(450, 120) 
        self.full_node_button.setIconSize(QSize(100, 100))
        self.full_node_button.setStyleSheet('background-color: black; color: green; border: 5px solid green; border-radius: 20px; font-weight: bold; font-size: 30px; padding-right: 30px;') 
        self.full_node_button.clicked.connect(self.launch_full_node_clicked)
        self.full_node_button.pressed.connect(self.button_flash_green)
        self.full_node_button.released.connect(self.button_reset_color)
        button_layout.addWidget(self.full_node_button, alignment=Qt.AlignBottom)

        self.mine_etc_button = QPushButton('MINE ETCPOW', self)
        scaled_logo_image = logo_image.scaled(scaled_width, scaled_height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.mine_etc_button.setIcon(QIcon('ETCPOW LOGO 1.png'))
        self.mine_etc_button.setFixedSize(370, 120)
        self.mine_etc_button.setIconSize(QSize(100, 100))
        self.mine_etc_button.setStyleSheet('background-color: black; color: yellow; border: 5px solid yellow; border-radius: 20px; font-weight: bold; font-size: 30px; padding-right: 20px;')
        self.mine_etc_button.clicked.connect(self.mine_etc_button_clicked)
        self.mine_etc_button.pressed.connect(self.button_flash_yellow)
        self.mine_etc_button.released.connect(self.button_reset_color_yellow)
        button_layout.addWidget(self.mine_etc_button, alignment=Qt.AlignBottom)
               
        self.stop_node_button = QPushButton('STOP NODE', self)
        self.stop_node_button.setStyleSheet('background-color: black; color: red; border: 5px solid red; border-radius: 20px; font-weight: bold; font-size: 30px;')
        self.stop_node_button.setFixedSize(250, 120)
        self.stop_node_button.clicked.connect(self.stop_node)
        self.stop_node_button.pressed.connect(self.button_flash_red_large)
        self.stop_node_button.released.connect(self.button_reset_color_large)
        button_layout.addWidget(self.stop_node_button, alignment=Qt.AlignBottom)

        self.mordor_node_button = QPushButton('LAUNCH MORDOR', self)
        self.mordor_node_button.setStyleSheet('background-color: black; color: blue; border: 5px solid blue; border-radius: 20px; font-weight: bold; font-size: 30px;')
        self.mordor_node_button.setFixedSize(320, 120)
        self.mordor_node_button.clicked.connect(self.launch_mordor_node_clicked)
        self.mordor_node_button.pressed.connect(self.button_flash_blue)
        self.mordor_node_button.released.connect(self.button_reset_blue)
        button_layout.addWidget(self.mordor_node_button, alignment=Qt.AlignBottom)

        self.fast_node_button = QPushButton('LAUNCH FAST NODE', self)
        scaled_logo_image = logo_image.scaled(scaled_width, scaled_height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.fast_node_button.setIcon(QIcon('ETCMC LOGO 1.png'))
        self.fast_node_button.setIconSize(QSize(100, 100))
        self.fast_node_button.setFixedSize(450, 120)
        self.fast_node_button.setStyleSheet('background-color: black; color: green; border: 5px solid green; border-radius: 20px; font-weight: bold; font-size: 30px; padding-right: 30px;')
        self.fast_node_button.clicked.connect(self.launch_fast_node_clicked)
        self.fast_node_button.pressed.connect(self.button_flash_green)
        self.fast_node_button.released.connect(self.button_reset_color)
        button_layout.addWidget(self.fast_node_button, alignment=Qt.AlignBottom)

        self.click_sound = QSoundEffect()
        self.click_sound.setSource(QUrl.fromLocalFile('click_sound.wav'))

        help_layout = QHBoxLayout()
        main_layout.addLayout(help_layout)

        twitter_button = QPushButton()
        twitter_button.setStyleSheet('border: 2.5px solid blue;')
        twitter_button.setIcon(QIcon('TWITTER QR.png'))
        twitter_button.setIconSize(QSize(50, 50))
        twitter_button.clicked.connect(lambda: webbrowser.open('https://twitter.com/ETCMC777'))
        help_layout.addWidget(twitter_button)

        telegram_button = QPushButton()
        telegram_button.setStyleSheet('border: 2.5px solid blue;')
        telegram_button.setIcon(QIcon('TELEGRAM QR.jpeg'))
        telegram_button.setIconSize(QSize(50, 50))
        telegram_button.clicked.connect(lambda: webbrowser.open('https://t.me/+CQwvIKSAujY4ZmVk'))
        help_layout.addWidget(telegram_button)

        help_label = QLabel('Help/Support:')
        help_label.setStyleSheet('color: green; font-size: 16px; font-weight: bold;')
        help_layout.addWidget(help_label)
        help_layout.addStretch()

        email_label = QLabel('etcmc-admin@etcmc.org or visit')
        email_label.setStyleSheet('color: green; font-size: 16px; font-weight: bold;')
        help_layout.addWidget(email_label)

        website_button = QPushButton('@www.etcmc.org', self)
        website_button.setStyleSheet('color: blue; font-size: 16px; font-weight: bold; border: none;')
        website_button.clicked.connect(lambda: webbrowser.open('http://www.etcmc.org'))
        help_layout.addWidget(website_button)

        help_layout.addStretch(10)

        self.node_output = QTextEdit()
        self.node_output.setFont(QFont("monospace"))
        self.node_output.setStyleSheet('background-color: black; color: green; border: 5px solid green; border-radius: 10px; font-size: 12px; font-weight: bold;')
        self.node_output.setReadOnly(True)
        main_layout.addWidget(self.node_output)
        self.node_output.moveCursor(self.node_output.textCursor().End)
        self.node_output.ensureCursorVisible()
       
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_metrics)
        self.update_timer.start(1000)

        self.update_counters_timer = QTimer()
        self.update_counters_timer.timeout.connect(self.update_counters)  
        self.update_counters_timer.start(1000) 

        self.update_etc_usd()
        self.etc_usd_timer = QTimer(self)
        self.etc_usd_timer.timeout.connect(self.update_etc_usd)
        self.etc_usd_timer.start(60000)  

        self.transaction_count = 0
        if os.path.exists('transaction_count.txt.enc'):
            decrypted_data = decrypt_file('transaction_count.txt.enc', ENCRYPTION_KEY)
            self.transaction_count = int(decrypted_data.decode())
        self.transaction_count_label.setText(f'Transaction Count: {self.transaction_count}')

        self.etcpow_balance = 0.000
        if os.path.exists('etcpow_balance.txt.enc'):
            decrypted_data = decrypt_file('etcpow_balance.txt.enc', ENCRYPTION_KEY)
            self.etcpow_balance = float(decrypted_data.decode())
        self.etcpow_balance_label.setText(f'ETCPOW Balance: {self.etcpow_balance:.3f}')

        self.show()


    def encrypt_and_save_file(self, file_name, data, key):
        cipher_suite = Fernet(key)
        encrypted_text = cipher_suite.encrypt(data.encode())
    
        with open(file_name, 'wb') as file:
            file.write(encrypted_text)

    def register_node_dialog(self):
        node_dialog = QtWidgets.QDialog(self)
        node_dialog.setWindowTitle("To receive a free membership NFT for the ETCMC DAO please register your details")
        node_dialog.resize(550, 400) 

        username_input = QtWidgets.QLineEdit(node_dialog)
        email_input = QtWidgets.QLineEdit(node_dialog)
        wallet_address_input = QtWidgets.QLineEdit(node_dialog)

        ok_button = QtWidgets.QPushButton("Submit", node_dialog)

        processing_label = QtWidgets.QLabel(node_dialog)
        processing_label.hide()

        progress_bar = QtWidgets.QProgressBar(node_dialog)
        progress_bar.hide()

    
        def validate_and_send():
            username = username_input.text()
            email = email_input.text()
            wallet_address = wallet_address_input.text()

            if not username:
                self.show_error("Username is required!")
                return
            if not email:
                self.show_error("Email is required!")
                return
            if not wallet_address:
                self.show_error("Wallet address is required!")
                return
           
            ok_button.setEnabled(False)
          
            processing_label.setText("Processing...")
            processing_label.show()
            node_dialog.repaint()
           
            progress_bar.show()
            progress_bar.setValue(0)
            
            progress_timer = QTimer()
            progress_timer.setInterval(50)  

            
            def update_progress():
                current_value = progress_bar.value()
                new_value = current_value + 1
                progress_bar.setValue(new_value)
                if new_value >= 100:
                    progress_timer.stop()

            progress_timer.timeout.connect(update_progress)
            progress_timer.start()

            QTimer.singleShot(5000, lambda: self.process_registration(username, email, wallet_address, processing_label, progress_bar, progress_timer, ok_button, node_dialog))

        ok_button.clicked.connect(validate_and_send)

        layout = QtWidgets.QVBoxLayout(node_dialog)
        layout.addWidget(QtWidgets.QLabel("Username"))
        layout.addWidget(username_input)
        layout.addWidget(QtWidgets.QLabel("Email"))
        layout.addWidget(email_input)
        layout.addWidget(QtWidgets.QLabel("ETC Wallet Address"))
        layout.addWidget(wallet_address_input)
        layout.addWidget(processing_label)
        layout.addWidget(progress_bar)
        layout.addWidget(ok_button)

        node_dialog.exec_()

    def send_node_info_email(self, username, email, wallet_address):
        decrypted_env = decrypt_file('.env.enc', ENCRYPTION_KEY)
        load_dotenv(io.StringIO(decrypted_env.decode()))
        your_email = os.getenv("EMAIL_ADDRESS")
        your_password = os.getenv("EMAIL_PASSWORD")
        to_email = "etcmc1claims@gmail.com"  

        msg = MIMEMultipart()
        msg["From"] = your_email
        msg["To"] = to_email
        msg["Subject"] = "Node Registration Notification"

        body = f"User {username} has registered a node.\nEmail: {email}\nWallet Address: {wallet_address}"
        msg.attach(MIMEText(body, "plain"))

        try:
            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()
            server.login(your_email, your_password)
            text = msg.as_string()
            server.sendmail(your_email, to_email, text)
            server.quit()
            return True
        except Exception as e:
            print(f"Error sending email: {e}")
            return False

    def send_node_info_email(self, username, email, wallet_address):
        decrypted_env = decrypt_file('.env.enc', ENCRYPTION_KEY)
        load_dotenv(io.StringIO(decrypted_env.decode()))
        your_email = os.getenv("EMAIL_ADDRESS")
        your_password = os.getenv("EMAIL_PASSWORD")
        to_email = "etcmc1claims@gmail.com"  

        msg = MIMEMultipart()
        msg["From"] = your_email
        msg["To"] = to_email
        msg["Subject"] = "Node Registration Notification"

        body = f"User {username} has registered a node.\nEmail: {email}\nWallet Address: {wallet_address}"
        msg.attach(MIMEText(body, "plain"))

        try:
            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()
            server.login(your_email, your_password)
            text = msg.as_string()
            server.sendmail(your_email, to_email, text)
            server.quit()
            return True
        except Exception as e:
            print(f"Error sending email: {e}")
            return False

    def process_registration(self, username, email, wallet_address, processing_label, progress_bar, progress_timer, ok_button, node_dialog):       
        progress_bar.hide()
        processing_label.show()

        try:
            if self.send_node_info_email(username, email, wallet_address):
               with open('node_registered.txt.enc', 'wb') as file:
                   file.write(encrypt_file('True', ENCRYPTION_KEY))
               self.register_node_button.setText('NODE REGISTERED')
               self.register_node_button.setEnabled(False)
               processing_label.setText("Registration Successful")
               QApplication.beep()
            else:               
               processing_label.setText("Error sending email.")
               self.show_error("There was an issue processing your registration. Please try again later.")
        except Exception as e:
            print(f"Error processing registration: {e}")
            self.show_error("There was an error processing your registration. Please try again later.")

    def check_node_registered(self):
        try:
            decrypted_data = decrypt_file('node_registered.txt.enc', ENCRYPTION_KEY)
            node_registered = decrypted_data.decode().strip()
            return node_registered == 'True'
        except FileNotFoundError:
            return False

        
    def show_reset_confirmation_dialog(self):
        confirmation_dialog = StyledMessageBox.create_styled_message_box(
            title="Reset Transaction Count?",
            text="Are you sure you want to reset the transaction count?",
            window_title="Reset Confirmation",
            icon_path="ETCMC LOGO 1.png"
        )
            
        confirm_button = confirmation_dialog.addButton("Confirm", QMessageBox.AcceptRole)
        confirmation_dialog.addButton("Cancel", QMessageBox.RejectRole)
           
        confirmation_dialog.exec_()
    
        if confirmation_dialog.clickedButton() == confirm_button:
            self.reset_and_save_transaction_count()


    def reset_and_save_transaction_count(self):
        self.transaction_count = 0
        self.transaction_count_label.setText(f'Transaction Count: {self.transaction_count}')
        self.save_transaction_count()  

 
    def show_popup(self):
        if not self.is_node_ready(self):            
            return
            
        self.popup = PopUp(send_json_request=self.send_json_request)
        self.popup.exec_()


    def send_json_request(self, json_request_text):      
        self.popup.text_edit.clear()
       
        self.popup.text_label.setText("Sending request...")
        
        try:
            request_json = json.loads(json_request_text)
            method = request_json.get("method", "")
        except ValueError as e:
            error_message = f"Error parsing request JSON: {e}"
            QMessageBox.warning(self.popup, "Error", error_message)
            return
       
        if not self.rpc_endpoint or not self.is_node_ready(self.popup):
            error_message = "Error: Ethereum node is not running."
            QMessageBox.warning(self.popup, "Error", error_message)
            return
       
        try:
            response = requests.post(
                url=self.rpc_endpoint,
                headers={"Content-Type": "application/json"},
                data=json_request_text.encode(),
            )
        except requests.exceptions.RequestException as e:
            error_message = f"Error sending request: {e}"
            QMessageBox.warning(self.popup, "Error", error_message)
            return
        
        if response.status_code != 200:
            error_message = f"Error sending request: HTTP {response.status_code} {response.reason}"
            QMessageBox.warning(self.popup, "Error", error_message)
            return
        
        try:
            response_json = response.json()
        except ValueError as e:
            error_message = f"Error parsing response: {e}"
            QMessageBox.warning(self.popup, "Error", error_message)
            return
       
        self.process_response(method, response_json)
        
        response_text = json.dumps(response_json, indent=4)
        self.popup.text_edit.append(response_text)

    def process_response(self, method, response_json):
        additional_text = ""

        if "result" in response_json:
            result = response_json["result"]

            if method == "eth_blockNumber" and result.startswith("0x"):
                decimal_block_number = int(result, 16)
                additional_text = f"\n\n----\nBlock number: {decimal_block_number}\n----"                
        
        if additional_text:
            self.popup.text_edit.append(additional_text)

    def claim_etcpow(self):
        print("Claim ETCPOW button clicked")
       
        print("Creating and showing Wallet Address dialog...")
        wallet_address_dialog = QDialog(self)
        wallet_address_dialog.setWindowTitle("Enter Wallet Address and Username")
        wallet_address_dialog.setFixedSize(400, 300)
        wallet_address_dialog.setWindowIcon(QIcon('ETCMC LOGO 1.png'))
        wallet_address_dialog.setStyleSheet("""
            QDialog {
                background-color: black;
                border: 2.5px solid green;
            }
            QLabel {
                color: green;
            }
            QLineEdit {
                background-color: white;
                color: green;
                border: 2.5px solid green;
            }
            QPushButton {
                background-color: green;
                color: black;
                border: none;
                padding: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5AC35A;
            }
        """)
        
        dialog_layout = QVBoxLayout()
       
        wallet_address_input = QLineEdit()
        wallet_address_input.setPlaceholderText("Enter your Ethereum Classic wallet address")
        dialog_layout.addWidget(wallet_address_input)
       
        username_input = QLineEdit()
        username_input.setPlaceholderText("Enter your username")
        dialog_layout.addWidget(username_input)
        
        ok_button = QPushButton("OK")
        dialog_layout.addWidget(ok_button)
        
        processing_label = QLabel("")
        processing_label.hide()
        dialog_layout.addWidget(processing_label)
        
        progress_bar = QProgressBar()
        progress_bar.setRange(0, 100)
        progress_bar.hide()
        dialog_layout.addWidget(progress_bar)
       
        wallet_address_dialog.setLayout(dialog_layout)

            
        def send_claim():
            user_wallet_address = wallet_address_input.text()
            username = username_input.text()

            if not user_wallet_address or not username:
                note_msg = StyledMessageBox.create_styled_message_box("Note", "ETCPOW payments will be made once a month.", "Information", "ETCMC LOGO 1.png")
                note_msg.exec_()
                return

            ok_button.setEnabled(False)
            
            progress_bar.show()
            processing_label.hide()
            
            processing_label.setText("Processing...")
            processing_label.show()
            wallet_address_dialog.repaint()
            
            note_msg = StyledMessageBox.create_styled_message_box("Note", "ETCPOW payments will be made once a month.", "Information", "ETCMC LOGO 1.png")                                
            note_msg.exec_()
            
            progress_bar.show()
            progress_bar.setValue(0)
            processing_label.setText("Processing...")
           
            progress_timer = QTimer()
            progress_timer.setInterval(50)  
            
            def update_progress():
                current_value = progress_bar.value()
                new_value = current_value + 1
                progress_bar.setValue(new_value)
                if new_value >= 100:
                    progress_timer.stop()

            progress_timer.timeout.connect(update_progress)
            progress_timer.start()

            QTimer.singleShot(5000, lambda: process_claim(user_wallet_address, username, self.etcpow_balance))

        def process_claim(user_wallet_address, username, etcpow_balance):            
            email_sent = send_email(user_wallet_address, username, self.etcpow_balance)
           
            progress_bar.hide()
            processing_label.show()
           
            if email_sent is True:
                self.etcpow_balance = 0
                self.etcpow_balance_label.setText(f'ETCPOW Balance: {self.etcpow_balance:.3f}')
                ok_button.setEnabled(False)
                self.save_etcpow_balance()

                self.update_claim_button_style()
                processing_label.setText("Claim Successful")
                
                QApplication.beep()
               
                ok_button.setEnabled(True)
                
                ok_button.clicked.disconnect(send_claim)
                
                ok_button.clicked.connect(wallet_address_dialog.close)
            
            else:
                error_msg = create_styled_message_box(QMessageBox.Warning, "Warning", "There was an issue processing your claim. Please try again later.", "Warning")
                error_msg.exec_()
                ok_button.setEnabled(True)
       
        ok_button.clicked.connect(send_claim)
        
        wallet_address_dialog.exec_()

    def update_etc_usd(self):
        api_url = "https://api.coingecko.com/api/v3/simple/price?ids=ethereum-classic&vs_currencies=usd"
        response = requests.get(api_url)
        etc_usd = response.json()["ethereum-classic"]["usd"]
        self.etc_usd_label.setText(f"ETC/USD: {etc_usd:.2f}")

    def is_besu_process_running(self):  
        for process in psutil.process_iter(['name']):
            if process.info['name'].lower() == 'java.exe':
                return True
        return False   


    def launch_full_node_clicked(self):
        if not self.transaction_counter_enabled:
            if os.path.exists('transaction_count.txt.enc'):
                self.load_transaction_count()

            if self.process and self.process.state() == QProcess.Running:
                self.stop_node()

                while self.is_besu_process_running():
                    self.node_output.append("Waiting for previous node to stop. Initializing, please wait...")
                    QThread.sleep(1)
            self.mine_etc = False 
            self.start_node("START FULL NODE.bat")

            try:
                self.update_counters_timer.timeout.disconnect(self.update_counters)
            except TypeError:
                pass

            self.update_counters_timer.timeout.connect(self.update_transaction_counter_only)
            self.update_counters_timer.start(1000)
            self.transaction_counter_enabled = True
        else:
            if self.process and self.process.state() == QProcess.Running:
                self.stop_node()

                while self.is_besu_process_running():
                    self.node_output.append("Waiting for previous node to stop. Initializing, please wait...")
                    QThread.sleep(1)

            self.start_node("START FULL NODE.bat")


    def launch_fast_node_clicked(self):
        if not self.transaction_counter_enabled:
            if os.path.exists('transaction_count.txt.enc'):
                self.load_transaction_count()

            if self.process and self.process.state() == QProcess.Running:
                self.stop_node()

                while self.is_besu_process_running():
                    self.node_output.append("Waiting for previous node to stop. Initializing, please wait...")
                    QThread.sleep(1)
                
            self.mine_etc = False       
            self.start_node("START FAST NODE1.bat")

            try:
                self.update_counters_timer.timeout.disconnect(self.update_counters)
            except TypeError:
                pass

            self.update_counters_timer.timeout.connect(self.update_transaction_counter_only)
            self.update_counters_timer.start(1000)
            self.transaction_counter_enabled = True
        
        else:
            if self.process and self.process.state() == QProcess.Running:
                self.stop_node()

                while self.is_besu_process_running():
                    self.node_output.append("Waiting for previous node to stop. Initializing, please wait...")
                    QThread.sleep(1)

            self.start_node("START FAST NODE1.bat")
    
        print("launch_fast_node_clicked called")
        print("transaction_counter_enabled:", self.transaction_counter_enabled)
        print("update_counters_timer.remainingTime():", self.update_counters_timer.remainingTime())
        print("update_counters_timer.isActive():", self.update_counters_timer.isActive())
        print("update_counters_timer.timerId():", self.update_counters_timer.timerId())

    def launch_mordor_node_clicked(self):        
        if not self.transaction_counter_enabled:
            if os.path.exists('transaction_count.txt.enc'):
                 self.load_transaction_count()

            if self.process and self.process.state() == QProcess.Running:
                self.stop_node()

                while self.is_besu_process_running():
                    self.node_output.append("Waiting for previous node to stop. Initializing, please wait...")
                    QThread.sleep(1)
            self.mine_etc = False  
            self.start_node("START MORDOR.bat")

            try:
                self.update_counters_timer.timeout.disconnect(self.update_counters)
            except TypeError:
                pass

            self.update_counters_timer.timeout.connect(self.update_transaction_counter_only)
            self.update_counters_timer.start(1000)
            self.transaction_counter_enabled = True
        else:
            if self.process and self.process.state() == QProcess.Running:
                self.stop_node()

                while self.is_besu_process_running():
                    self.node_output.append("Waiting for previous node to stop. Initializing, please wait...")
                    QThread.sleep(1)

            self.start_node("START MORDOR.bat")


    def mine_etc_button_clicked(self):
        if not self.transaction_counter_enabled:
            if os.path.exists('transaction_count.txt.enc'):
                self.load_transaction_count()
            else:
                self.transaction_count = 0

            if self.process and self.process.state() == QProcess.Running:
                self.stop_node()

                while self.is_besu_process_running():
                    self.node_output.append("Waiting for previous node to stop. Initializing, please wait...")
                    QThread.sleep(1)
            self.mine_etc = True 
            self.start_node("START FAST NODE.bat")
           
            try:
                self.update_counters_timer.timeout.disconnect(self.update_transaction_counter_only)
            except TypeError:
                pass
           
            self.update_counters_timer.timeout.connect(self.update_counters)
            self.update_counters_timer.start(1000)
            self.transaction_counter_enabled = True
        else:
            if self.process and self.process.state() == QProcess.Running:
                self.stop_node()

                while self.is_besu_process_running():
                    self.node_output.append("Waiting for previous node to stop. Initializing, please wait...")
                    QThread.sleep(1)

            self.start_node("START FAST NODE.bat")


    def update_counters(self, update_etcpow_balance=True):
        print("update_counters_called")
        if not self.transaction_counter_enabled:
            return
        print("update_counters method is active")
        output = self.node_output.toPlainText()
        
        if not hasattr(self, 'enode_url') or not hasattr(self, 'public_key') or not hasattr(self, 'node_id') or not hasattr(self, 'node_address') or not hasattr(self, 'rpc_endpoint'):
           
            enode_url_pattern = r"Enode URL (enode://[\w:@.]+)"
            enode_url_match = re.search(enode_url_pattern, output)
            if enode_url_match:
                self.enode_url = enode_url_match.group(1)
                print("Enode URL found:", self.enode_url)
                self.node_id_label.setText(f'Enode URL: {self.enode_url}')
            else:
                print("Enode URL not found in output:", output)
           
            public_key_pattern = r"publicKey=0x[a-fA-F0-9]{66}"
            public_key_match = re.search(public_key_pattern, output)
            if public_key_match:
                self.public_key = public_key_match.group()
                print("Public Key found:", self.public_key)
                self.node_id_label.setText(f'Public Key: {self.public_key}')
            else:
                print("Public Key not found in output:", output)
            
            node_id_pattern = r"nodeId=0x[a-fA-F0-9]{64}"
            node_id_match = re.search(node_id_pattern, output)
            if node_id_match:
                self.node_id = node_id_match.group()
                print("Node ID found:", self.node_id)
                self.node_id_label.setText(f'Node ID: {self.node_id}')
            else:
                print("Node ID not found in output:", output)
           
            node_address_pattern = r"Node address (0x[a-fA-F0-9]{40})"
            node_address_match = re.search(node_address_pattern, output)
            if node_address_match:
                self.node_address = node_address_match.group(1)
                print("Node Address found:", self.node_address)
                self.node_id_label.setText(f'Node Address: {self.node_address}')
            else:
                print("Node address not found in output:", output)
           
            rpc_endpoint_pattern = r"JSON-RPC service started and listening on (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+)"
            rpc_endpoint_match = re.search(rpc_endpoint_pattern, output)
            if rpc_endpoint_match:
                self.rpc_endpoint = "http://" + rpc_endpoint_match.group(1)
                print("JSON-RPC found:", self.rpc_endpoint)
                self.node_id_label.setText(f'RPC Endpoint: {self.rpc_endpoint}')
            else:
                print("RPC Endpoint not found in output:", output)
       
        new_matches_count = len(re.findall(r'Import', output[self.last_checked_position:]))
        if new_matches_count > 0:
            print("Updating ETCPOW balance")            
            self.transaction_count += new_matches_count
            self.transaction_count_label.setText(f'Transaction Count: {self.transaction_count}')
            self.save_transaction_count()

            if update_etcpow_balance:
                etcpow_increment = 0.001
                self.etcpow_balance += new_matches_count * etcpow_increment
                self.etcpow_balance_label.setText(f'ETCPOW Balance: {self.etcpow_balance:.3f}')
                self.save_etcpow_balance()
            self.update_claim_button_style()
            
            self.last_checked_position = len(output)

        if hasattr(self, 'rpc_endpoint'):
            return self.rpc_endpoint

        

    def update_transaction_counter_only(self):
        print("update_transaction_counter_only called") 
        if not self.transaction_counter_enabled:
            return
        print("update_transaction_counter_only method is active")
        output = self.node_output.toPlainText()

        if not hasattr(self, 'enode_url') or not hasattr(self, 'public_key') or not hasattr(self, 'node_id') or not hasattr(self, 'node_address') or not hasattr(self, 'rpc_endpoint'):
           
            enode_url_pattern = r"Enode URL (enode://[\w:@.]+)"
            enode_url_match = re.search(enode_url_pattern, output)
            if enode_url_match:
                self.enode_url = enode_url_match.group(1)
                print("Enode URL found:", self.enode_url)
                self.node_id_label.setText(f'Enode URL: {self.enode_url}')
            else:
                print("Enode URL not found in output:", output)
           
            public_key_pattern = r"publicKey=0x[a-fA-F0-9]{66}"
            public_key_match = re.search(public_key_pattern, output)
            if public_key_match:
                self.public_key = public_key_match.group()
                print("Public Key found:", self.public_key)
                self.node_id_label.setText(f'Public Key: {self.public_key}')
            else:
                print("Public Key not found in output:", output)
            
            node_id_pattern = r"nodeId=0x[a-fA-F0-9]{64}"
            node_id_match = re.search(node_id_pattern, output)
            if node_id_match:
                self.node_id = node_id_match.group()
                print("Node ID found:", self.node_id)
                self.node_id_label.setText(f'Node ID: {self.node_id}')
            else:
                print("Node ID not found in output:", output)
          
            node_address_pattern = r"Node address (0x[a-fA-F0-9]{40})"
            node_address_match = re.search(node_address_pattern, output)
            if node_address_match:
                self.node_address = node_address_match.group(1)
                print("Node Address found:", self.node_address)
                self.node_id_label.setText(f'Node Address: {self.node_address}')
            else:
                print("Node address not found in output:", output)
            
            rpc_endpoint_pattern = r"JSON-RPC service started and listening on (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+)"
            rpc_endpoint_match = re.search(rpc_endpoint_pattern, output)
            if rpc_endpoint_match:
                self.rpc_endpoint = "http://" + rpc_endpoint_match.group(1)
                print("JSON-RPC found:", self.rpc_endpoint)
                self.node_id_label.setText(f'RPC Endpoint: {self.rpc_endpoint}')
            else:
                print("RPC Endpoint not found in output:", output)
       
        new_matches_count = len(re.findall(r'Import', output[self.last_checked_position:]))
        if new_matches_count > 0:
            
            self.transaction_count += new_matches_count
            self.transaction_count_label.setText(f'Transaction Count: {self.transaction_count}')
            self.save_transaction_count()
           
            self.last_checked_position = len(output)

        if hasattr(self, 'rpc_endpoint'):
            return self.rpc_endpoint


    def save_transaction_count(self):
        self.encrypt_and_save_file('transaction_count.txt.enc', str(self.transaction_count), ENCRYPTION_KEY)

    def load_transaction_count(self):
        self.transaction_count = 0
        if os.path.exists('transaction_count.txt.enc'):
            decrypted_data = decrypt_file('transaction_count.txt.enc', ENCRYPTION_KEY)
            self.transaction_count = int(decrypted_data.decode())
        self.transaction_count_label.setText(f'Transaction Count: {self.transaction_count}')

    def save_etcpow_balance(self):
        self.encrypt_and_save_file('etcpow_balance.txt.enc', str(self.etcpow_balance), ENCRYPTION_KEY)

    def load_etcpow_balance(self):
        self.etcpow_balance = 0.000
        if os.path.exists('etcpow_balance.txt.enc'):
            decrypted_data = decrypt_file('etcpow_balance.txt.enc', ENCRYPTION_KEY)
            self.etcpow_balance = float(decrypted_data.decode())
        self.etcpow_balance_label.setText(f'ETCPOW Balance: {self.etcpow_balance:.3f}')

    def update_claim_button_style(self):
        if self.etcpow_balance >= 100:
            self.claim_button.setEnabled(True)
            self.claim_button.setStyleSheet('color: yellow; background-color: black; border: 5px solid yellow; padding: 5px; font-weight: bold; font-size: 14px;')
        else:
            self.claim_button.setEnabled(False)
            self.claim_button.setStyleSheet('color: grey; background-color: black; border: 5px solid gray; padding: 5px; font-weight: bold; font-size: 14px;')        

    def button_flash_blue(self):
        sender = self.sender()
        sender.setStyleSheet('background-color: blue; color: black; border: 5px solid blue; border-radius: 20px; font-weight: bold; font-size: 30px;')
        self.click_sound.play()

    def button_reset_blue(self):
        sender = self.sender()
        sender.setStyleSheet('background-color: black; color: blue; border: 5px solid blue; border-radius: 20px; font-weight: bold; font-size: 30px;')

    def button_flash_yellow1(self):
        sender = self.sender()
        sender.setStyleSheet('color: black; background-color: yellow; border: 5px solid yellow; padding: 5px; font-weight: bold; font-size: 14px;')
        self.click_sound.play()

    def button_reset_yellow1(self):
        sender = self.sender()
        sender.setStyleSheet('color: yellow; background-color: black; border: 5px solid yellow; padding: 5px; font-weight: bold; font-size: 14px;')

    def button_flash_blue_small(self):
        sender = self.sender()
        sender.setStyleSheet('color: black; background-color: blue; border: 5px solid blue; padding: 5px; font-weight: bold; font-size: 14px;')
        self.click_sound.play()
       
    def button_reset_color_small(self):
        sender = self.sender()
        sender.setStyleSheet('color: blue; background-color: black; border: 5px solid blue; padding: 5px; font-weight: bold; font-size: 14px;')
        
    def button_flash_red_large(self):
        sender = self.sender()
        sender.setStyleSheet('background-color: red; color: black; border: 5px solid red; border-radius: 20px; font-weight: bold; font-size: 30px;')
        self.click_sound.play()

    def button_reset_color_large(self):
        sender = self.sender()
        sender.setStyleSheet('background-color: black; color: red; border: 5px solid red; border-radius: 20px; font-weight: bold; font-size: 30px;')

    def stop_node(self):
        if self.process:
            self.process.kill()
            self.process.waitForFinished()
            self.stop_ports()
            self.last_checked_position = 0
            self.encrypt_and_save_file('transaction_count.txt.enc', str(self.transaction_count), ENCRYPTION_KEY)
            self.node_output.append("Node process stopped.")
            self.node_output.moveCursor(self.node_output.textCursor().End)
            self.update_counters_timer.stop()

            try:
                self.update_counters_timer.timeout.disconnect()
            except TypeError:
                pass

            if hasattr(self, 'enode_url'): del self.enode_url
            if hasattr(self, 'public_key'): del self.public_key
            if hasattr(self, 'node_id'): del self.node_id
            if hasattr(self, 'node_address'): del self.node_address
            if hasattr(self, 'rpc_endpoint'): del self.rpc_endpoint

    def stop_ports(self):
        for conn in psutil.net_connections():
            if conn.status == psutil.CONN_LISTEN:
                continue  
            if conn.laddr.port < 1024:
                continue 
            try:
                p = psutil.Process(conn.pid)
                if "java" in p.name().lower():
                    p.kill()
                    print(f"Killed process {p.name()} with PID {p.pid} using port {conn.laddr.port}")
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass


    def show_node_id(self):
        if not is_node_ready():
            self.node_output.append("Error: Node is still initializing.")
            self.node_output.moveCursor(self.node_output.textCursor().End)
            self.node_output.ensureCursorVisible()
            return

        if self.process is not None and self.process.state() == QProcess.Running:
            if self.node_id_label.isVisible():
                self.node_id_label.setText("Node DATA: N/A")
                self.node_id_label.setVisible(False)
                self.node_id_label.setFixedHeight(20)
            else:
                self.node_id_label.setText(f"Enode: {getattr(self, 'enode_url', 'N/A')}\nPublic Key: {getattr(self, 'public_key', 'N/A')}\nNode ID: {getattr(self, 'node_id', 'N/A')}\nNode Address: {getattr(self, 'node_address', 'N/A')}\nRPC Endpoint: {getattr(self, 'rpc_endpoint', 'N/A')}")
                self.node_id_label.setVisible(True)
                self.node_id_label.setFixedHeight(85)
        else:
            self.node_output.append("Error: Node is not running.")
            self.node_output.moveCursor(self.node_output.textCursor().End)
            self.node_output.ensureCursorVisible()

            if self.node_id_label.isVisible():
                self.node_id_label.setText("Node DATA: N/A")
                self.node_id_label.setVisible(False)
                self.node_id_label.setFixedHeight(20)

    def display_node_id_window(self, node_id):
        node_id_window = QDialog(self)
        node_id_window.setWindowTitle("Node ID")
        node_id_window.setWindowFlags(Qt.Dialog | Qt.WindowCloseButtonHint)
        node_id_window.setGeometry(0, 0, 300, 300)

        layout = QVBoxLayout()
        node_id_window.setLayout(layout)

        node_id_label = QLabel("Node ID: " + node_id)
        node_id_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(node_id_label)

        close_button = QPushButton("Close")
        close_button.clicked.connect(node_id_window.close)
        layout.addWidget(close_button)

        node_id_window.exec_()

    def closeEvent(self, event):
        self.save_transaction_count() 
        self.update_timer.stop()  
        if self.process:
            self.process.kill()
            self.process.waitForFinished()
        event.accept()

    def update_metrics(self):
        cpu_percent = psutil.cpu_percent()
        self.cpu_widget.setText(f"CPU: {cpu_percent:.1f}%")

        ram = psutil.virtual_memory()
        ram_percent = ram.percent
        self.ram_widget.setText(f"RAM: {ram_percent:.1f}%")

        disk = psutil.disk_usage('/')
        disk_percent = disk.percent
        self.disk_widget.setText(f"DISK: {disk_percent:.1f}%")

    def button_flash_green(self):
        sender = self.sender()
        sender.setStyleSheet('background-color: green; color: black; border: 5px solid green; border-radius: 20px; font-weight: bold; font-size: 30px; padding-right: 30px;')
        self.click_sound.play()

    def button_flash_yellow(self):
        sender = self.sender()
        sender.setStyleSheet('background-color: yellow; color: black; border: 5px solid yellow; border-radius: 20px; font-weight: bold; font-size: 30px; padding-right: 30px;')
        self.click_sound.play()

    def button_reset_color_yellow(self):
        sender = self.sender()
        sender.setStyleSheet('background-color: black; color: yellow; border: 5px solid yellow; border-radius: 20px; font-weight: bold; font-size: 30px; padding-right: 30px;')

    def button_reset_color(self):
        sender = self.sender()
        sender.setStyleSheet('background-color: black; color: green; border: 5px solid green; border-radius: 20px; font-weight: bold; font-size: 30px; padding-right: 30px;')

    def button_flash_blue_small2(self):
        self.sender().setStyleSheet('color: blue; background-color: black; border: 5px solid blue; padding: 5px; font-weight: bold; font-size: 14px;')
        self.click_sound.play()

    def button_reset_color_small2(self):
        self.sender().setStyleSheet('border: none; background-color: transparent; color: green; font-size: 14px; font-weight: bold;')
  
    def start_node(self, node_script):
        if self.process and self.process.state() == QProcess.Running:
            self.node_output.append("A node is already running. Please stop the current node before starting a new one.")
            return

        self.node_output.clear()
        script_path = os.path.join(".", node_script)
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(self.handle_output)
        self.process.readyReadStandardError.connect(self.handle_error)
        self.process.finished.connect(self.handle_finished)
        self.process.start('cmd.exe', ['/c', script_path])

        if self.transaction_counter_enabled:
            if node_script == "START FAST NODE.bat":
                self.update_counters_timer.timeout.connect(self.update_counters)  
                self.update_etcpow_balance = True 
            else:
                self.update_counters_timer.timeout.connect(self.update_transaction_counter_only) 
                self.update_etcpow_balance = False 
            self.update_counters_timer.start(1000)
        else:
            self.update_counters_timer.stop()

    def handle_output(self):
        data = self.process.readAllStandardOutput().data()
        text = data.decode(errors='replace').strip()
        self.node_output.append(text)
        self.node_output.moveCursor(self.node_output.textCursor().End)
        self.node_output.ensureCursorVisible()

    def handle_error(self):
        error = self.process.readAllStandardError().data()
        text = error.decode(errors='replace').strip()
        self.node_output.append(text)
        self.node_output.moveCursor(self.node_output.textCursor().End)
        self.node_output.ensureCursorVisible()

    def handle_finished(self):
        self.node_output.append("Node process finished.")
        self.node_output.moveCursor(self.node_output.textCursor().End)
        self.node_output.ensureCursorVisible()


    def is_node_ready(self, popup):
        try:
            response = requests.post(url=self.rpc_endpoint, headers={"Content-Type": "application/json"}, data=json.dumps({"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}))
            response.raise_for_status()
        except:
            error_message = "Unable to connect to Ethereum node. Please ensure the node is running and the RPC endpoint is correct."
            QMessageBox.warning(popup, "Error", error_message)
            return False

        return True

    def on_connect_wallet_button_clicked(self):
        if not self.is_node_ready(self):
            
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText("Error")
            msg.setInformativeText('Please start the node before connecting the wallet.')
            msg.setWindowTitle("Error")
            msg.setWindowIcon(QIcon('ETCMC LOGO 1.png'))  
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: black;
                    border: 2.5px solid green;
                }
                QLabel {
                    color: green;
                }
                QPushButton {
                    background-color: green;
                    color: black;
                    border: none;
                    padding: 5px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #5AC35A;
                }
            """)
            msg.exec_()
        else:            
            instructions = f"""
            INSTRUCTIONS
            1. Make sure your node is fully synced.
            2. Open MetaMask in your browser. If you haven't installed MetaMask yet, visit https://metamask.io and install the extension for your browser.
            3. Click on the circle icon in the top-right corner of MetaMask to open the account menu.
            4. Click on "Settings" at the bottom of the menu.
            5. Click on "Networks" in the Settings menu.
            6. Click on "Add Network" at the top-right corner of the Networks menu.
            7. Fill in the following details:
                - Network Name: My Custom Node
                - New RPC URL: {self.rpc_endpoint}
                - Chain ID: 61
            8. Click "Save".
            9. Your wallet is now connected to your custom node!
            """
            msg = QMessageBox()
            msg.setWindowTitle("Connect Wallet")
            msg.setText(instructions)
            msg.setWindowIcon(QIcon('ETCMC LOGO 1.png')) 
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: black;
                    border: 2.5px solid green;
                }
                QLabel {
                    color: green;
                }
                QPushButton {
                    background-color: green;
                    color: black;
                    border: none;
                    padding: 5px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #5AC35A;
                }
            """)
            msg.exec_()

            self.load_metamask_page()


    def load_metamask_page(self):
        webbrowser.open_new("https://metamask.io")

    def check_node_and_show_popup(self):
        if not self.is_node_ready():
           
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText("Error: Node is not running.")
            msg.exec_()
        else:           
            self.show_popup()


class PopUp(QDialog):
    def __init__(self, send_json_request, parent=None):
        super(PopUp, self).__init__(parent)

        self.send_json_request = send_json_request

        self.setWindowIcon(QIcon('ETCMC LOGO 1.png'))
        main_layout = QVBoxLayout()
        self.setLayout(main_layout)
        QApplication.instance().beep()
        
        label = QLabel('Enter your JSON request:')
        main_layout.addWidget(label)

        self.text_edit = QTextEdit()
        main_layout.addWidget(self.text_edit)

       
        self.text_label = QLabel()
        main_layout.addWidget(self.text_label)

       
        submit_button = QPushButton('Submit')
        submit_button.clicked.connect(self.submit)
        main_layout.addWidget(submit_button)

      
        requests_button = QPushButton('Pre-made Requests')
        requests_button.clicked.connect(self.show_requests_popup)
        main_layout.addWidget(requests_button)

      
        self.setWindowFlag(Qt.WindowStaysOnTopHint)
        self.setWindowTitle('JSON Request')
        self.setFixedSize(400, 200)
        self.setStyleSheet("""
            QDialog {
                background-color: black;
                border: 2.5px solid green;
            }
            QLabel {
                color: green;
            }
            QTextEdit {
                background-color: white;
                color: green;
                border: 2.5px solid green;
            }
            QPushButton {
                background-color: green;
                color: black;
                border: none;
                padding: 5px;
                font-weight: bold;
              }
            QPushButton:hover {
                background-color: #5AC35A;
            }
        """)

    def submit(self):      
        text = self.text_edit.toPlainText()
        self.send_json_request(text)
       
    def show_requests_popup(self):
        requests = [
            {"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":83},
            {"jsonrpc":"2.0","method":"eth_getBlockByNumber","params":["0x0", True],"id":1},
            {"jsonrpc":"2.0","method":"eth_gasPrice","params":[],"id":73},
            {"jsonrpc":"2.0","method":"eth_getTransactionCount","params":["0x79e4d4d3b5199e9d74d07f19511d1c91f4a4b7e1", "latest"],"id":3},
            {"jsonrpc":"2.0","method":"eth_getBalance","params":["0x79e4d4d3b5199e9d74d07f19511d1c91f4a4b7e1", "latest"],"id":5},
            {"jsonrpc":"2.0","method":"eth_getTransactionReceipt","params":["0xb27da38ecf7b7cb24e0581bfba931c75786bbac9e7a65c2a88939d3cb4433e2b"],"id":15},
            {"jsonrpc":"2.0","method":"eth_getTransactionByHash","params":["0xb27da38ecf7b7cb24e0581bfba931c75786bbac9e7a65c2a88939d3cb4433e2b"],"id":7},
            {"jsonrpc":"2.0","method":"eth_getCode","params":["0x79e4d4d3b5199e9d74d07f19511d1c91f4a4b7e1", "latest"],"id":1},
            {"jsonrpc":"2.0","method":"eth_getStorageAt","params":["0x79e4d4d3b5199e9d74d07f19511d1c91f4a4b7e1", "0x0", "latest"],"id":3},
            {"jsonrpc":"2.0","method":"eth_getTransactionReceipt","params":["0x29cfc21c562d00ff70c20ebedbfbf601432f6481a2466951ce8cbf18639fa5c5"],"id":2},
            {"jsonrpc":"2.0","method":"eth_getBlockByNumber","params":["latest", False],"id":21},
            {"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":22},
            {"jsonrpc":"2.0","method":"admin_peers","params":[],"id":23},
            {"jsonrpc":"2.0","method":"eth_mining","params":[],"id":24},
            {"jsonrpc":"2.0","method":"eth_hashrate","params":[],"id":25},
            {"jsonrpc":"2.0","method":"eth_syncing","params":[],"id":26},
            {"jsonrpc":"2.0","method":"eth_getUncleCountByBlockHash","params":["0x29cfc21c562d00ff70c20ebedbfbf601432f6481a2466951ce8cbf18639fa5c5"],"id":27},
            {"jsonrpc":"2.0","method":"eth_getUncleCountByBlockNumber","params":["0x0"],"id":28}
        ]
       
        requests_list = [json.dumps(request) for request in requests]

        self.requests_popup = RequestsPopUp(requests_list, self)

       
        if self.requests_popup.exec_():
            selected_request = self.requests_popup.selected_request
            self.text_edit.setText(selected_request)


class RequestsPopUp(QDialog):
    def __init__(self, requests_list, parent=None):
        super(RequestsPopUp, self).__init__(parent)
        
        self.requests_list = requests_list
              
        main_layout = QVBoxLayout()
        self.setLayout(main_layout)
        
        label = QLabel('Select a pre-made request:')
        main_layout.addWidget(label)
               
        scroll_area = QScrollArea()
        main_layout.addWidget(scroll_area)
        
        widget = QWidget()
        scroll_area.setWidget(widget)
        
        self.list_widget = QListWidget(widget)
        self.list_widget.addItems(requests_list)
        scroll_area.setWidgetResizable(True)
        scroll_area.setFixedHeight(200)
            
        submit_button = QPushButton('Select')
        submit_button.clicked.connect(self.select_request)
        main_layout.addWidget(submit_button)
               
        self.setWindowTitle('Pre-made Requests')
        self.setFixedSize(300, 400)
        self.setStyleSheet("""
            QDialog {
                background-color: black;
                border: 2.5px solid green;
            }
            QLabel {
                color: green;
            }
            QListWidget {
                background-color: white;
                color: green;
                border: 2.5px solid green;
            }
            QPushButton {
                background-color: green;
                color: black;
                border: none;
                padding: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5AC35A;
            }
        """)
    
    def select_request(self):
        current_item = self.list_widget.currentItem()
        if current_item is None:
            QMessageBox.warning(self, "Error", "No request selected.")
            return
        selected_request = current_item.text()
        self.selected_request = selected_request
        self.accept()        
   

class StyledMessageBox:
    @staticmethod
    def create_styled_message_box(title, text, window_title, icon_path):
        msg = QMessageBox()
        msg.setStyleSheet("QLabel{font-size: 12px;}")
        msg.setWindowIcon(QIcon('ETCMC LOGO 1.png'))
        msg.setText(text)
        msg.setWindowTitle(window_title)
        QApplication.instance().beep()
        msg.setStyleSheet("""
            QMessageBox {
                background-color: black;
                border: 2.5px solid green;
            }
            QLabel {
                color: green;
            }
            QPushButton {
                background-color: green;
                color: black;
                border: none;
                padding: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5AC35A;
            }
        """)
        return msg

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    window = EthereumNodeGUI()
    sys.exit(app.exec_())



 


